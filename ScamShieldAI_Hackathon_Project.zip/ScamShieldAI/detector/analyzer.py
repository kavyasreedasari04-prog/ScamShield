import re

# A transparent demonstration heuristic, not a trained AI model.
RULES = [
    (r"\b(pay|payment|transfer|deposit|registration fee|processing fee|upfront fee)\b", 25,
     "Requests payment or an upfront fee."),
    (r"\b(urgent|immediately|today only|act now|within \d+ hours|limited time)\b", 15,
     "Uses urgency or pressure to act quickly."),
    (r"\b(otp|password|pin|cvv|bank details|card details)\b", 25,
     "Mentions sensitive credentials or banking information."),
    (r"\b(prize|winner|won|lottery|free gift|claim reward)\b", 15,
     "Promises a prize or reward that may need verification."),
    (r"\b(selected|guaranteed job|work from home|earn ₹?\d+)\b", 10,
     "Makes a job or earnings claim that should be independently verified."),
    (r"https?://[^\s]+|www\.[^\s]+", 10,
     "Contains a link; verify the domain independently before opening it."),
    (r"\b(verify your account|account suspended|click here)\b", 15,
     "Uses common account-verification or click-through wording."),
]

def analyze_text(message):
    normalized = message.lower()
    reasons = []
    score = 0
    for pattern, points, explanation in RULES:
        if re.search(pattern, normalized, flags=re.IGNORECASE):
            score += points
            reasons.append(explanation)

    score = min(score, 100)
    if score >= 60:
        level = "High"
    elif score >= 30:
        level = "Medium"
    else:
        level = "Low"

    if not reasons:
        reasons.append("No configured warning pattern was detected. This does not prove the message is safe.")
    else:
        reasons.append("Verify the sender through an official channel; never share OTPs or pay a fee based only on a message.")
    return score, level, reasons
