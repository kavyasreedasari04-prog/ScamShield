from django.contrib import admin
from .models import Scan

@admin.register(Scan)
class ScanAdmin(admin.ModelAdmin):
    list_display = ("id", "risk_level", "risk_score", "reported", "created_at")
    list_filter = ("risk_level", "reported", "created_at")
    search_fields = ("message", "reasons")
    readonly_fields = ("created_at",)
