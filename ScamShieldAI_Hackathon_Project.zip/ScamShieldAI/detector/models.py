from django.db import models

class Scan(models.Model):
    message = models.TextField()
    risk_score = models.PositiveSmallIntegerField(default=0)
    risk_level = models.CharField(max_length=20, default="Low")
    reasons = models.TextField(blank=True)
    reported = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def reason_list(self):
        return [r for r in self.reasons.split("\n") if r.strip()]

    def __str__(self):
        return f"{self.risk_level} risk ({self.risk_score}/100) - {self.created_at:%Y-%m-%d %H:%M}"
