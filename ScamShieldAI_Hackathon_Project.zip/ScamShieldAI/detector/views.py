from django.contrib import messages
from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.http import require_POST
from .models import Scan
from .analyzer import analyze_text

def home(request):
    recent_scans = Scan.objects.filter(reported=False)[:5]
    return render(request, "detector/home.html", {"recent_scans": recent_scans})

@require_POST
def analyze(request):
    message_text = request.POST.get("message", "").strip()
    if not message_text:
        messages.error(request, "Please paste a message or URL to analyze.")
        return redirect("home")
    if len(message_text) > 5000:
        messages.error(request, "Please keep the text under 5,000 characters.")
        return redirect("home")
    score, level, reasons = analyze_text(message_text)
    scan = Scan.objects.create(
        message=message_text,
        risk_score=score,
        risk_level=level,
        reasons="\n".join(reasons),
    )
    return render(request, "detector/result.html", {"scan": scan})

def history(request):
    scans = Scan.objects.all()[:100]
    return render(request, "detector/history.html", {"scans": scans})

@require_POST
def report_scan(request, scan_id):
    scan = get_object_or_404(Scan, pk=scan_id)
    scan.reported = True
    scan.save(update_fields=["reported"])
    messages.success(request, "Report flag saved for admin review.")
    return redirect("history")
