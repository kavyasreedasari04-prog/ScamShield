from django.contrib import admin
from django.urls import path, include
from detector import views

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", views.home, name="home"),
    path("analyze/", views.analyze, name="analyze"),
    path("history/", views.history, name="history"),
    path("report/<int:scan_id>/", views.report_scan, name="report_scan"),
    path("accounts/", include("django.contrib.auth.urls")),
]
