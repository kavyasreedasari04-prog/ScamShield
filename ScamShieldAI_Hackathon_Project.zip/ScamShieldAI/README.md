# ScamShield AI — Full Stack Hackathon Prototype

## Features
- Responsive frontend (HTML/CSS)
- Python Django backend
- SQLite database stores scan history
- Explainable heuristic risk score and reasons
- Demo sample button
- Report/flag workflow
- Django admin dashboard

## Run on Windows (VS Code terminal)
1. Install Python 3.11+.
2. Open this folder in VS Code.
3. In PowerShell:
   ```powershell
   py -m venv venv
   .\venv\Scripts\Activate.ps1
   python -m pip install -r requirements.txt
   python manage.py makemigrations detector
   python manage.py migrate
   python manage.py createsuperuser
   python manage.py runserver
   ```
4. Open http://127.0.0.1:8000/
5. Admin: http://127.0.0.1:8000/admin/

## Important limitations
- This prototype uses transparent keyword/rule heuristics; it is not a trained AI model and does not verify a URL against live threat intelligence.
- Risk score is an indicator score, not a calibrated probability.
- The development settings are not production-ready. Do not deploy publicly without changing SECRET_KEY, setting DEBUG=False, configuring ALLOWED_HOSTS, HTTPS, privacy controls, rate limits, and appropriate data retention.
- Do not paste passwords, OTPs, banking details, or private messages containing personal data into the demo.
